#!/bin/bash
#SBATCH --qos=partner
#SBATCH --mem=128G
#SBATCH --partition=gpu
#SBATCH --job-name=3i3z_native_insulin
#SBATCH --time=96:00:00
#SBATCH --ntasks=28
#SBATCH --cpus-per-task=1
#SBATCH --gres=gpu:P100:2

module load openmpi
module load namd/2.13-multicore-CUDA

namd2 +p28 initialNVT.conf > initialNVT.log
namd2 +p28 initialNPT.conf > initialNPT.log
namd2 +p28 initialNPT_continue.conf > initialNPT_continue.log
namd2 +p28 relaxRestraints.conf > relaxRestraints.log
